<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', 'WelcomeController@index');

Route::any('/addItem', 'WelcomeController@adduser');

Route::any('/deleteItem', 'WelcomeController@deleteuser');

Route::any('/editItem', 'WelcomeController@edituser');
