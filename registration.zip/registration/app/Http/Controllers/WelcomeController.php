<?php 

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\userdatas;
use Validator;
use Response;
use Illuminate\Support\Facades\Input;

class WelcomeController extends Controller {

	public function index()
	{
		$data = userdatas::all();
		return view('welcome')->withData($data);
	}

	public function adduser(Request $request)
    {
        $rules = array(
                'fname' => 'required|alpha_num',
                'lname' => 'required|alpha_num',
                'email' => 'required',
                'mobile' => 'required',
        );
        $validator = Validator::make(Input::all(), $rules);
        if ($validator->fails()) {
            return Response::json(array(

                    'errors' => $validator->getMessageBag()->toArray(),
            ));
        } else {
            $data = new userdatas();
            $data->fname = $request->fname;
            $data->lname = $request->fname;
            $data->email = $request->email;
            $data->mobile = $request->mobile;
            $data->save();

            return response()->json($data);
        }
    }

    public function deleteuser(Request $req)
    {
    	userdatas::find($req->id)->delete();

        return response()->json();
    }

    public function edituser(Request $req)
    {
    	$data = userdatas::find($req->id);
        $data->fname = $req->fname;
        $data->save();

        return response()->json($data);
    }

}
