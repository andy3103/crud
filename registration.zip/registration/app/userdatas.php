<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class userdatas extends Model {

    public $timestamps = false;

}
